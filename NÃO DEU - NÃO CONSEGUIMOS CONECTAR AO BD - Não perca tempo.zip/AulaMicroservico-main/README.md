# Aula Microserviço

Este projeto é um exemplo de aplicação de microserviço utilizando Flask e PostgreSQL.

## Propósito

Este Repositorio foi criado para ensinar os alunos da UniFAAT a trabalharem com microserviço em Python.

## Estrutura do Projeto

├── InfraBD/ # Contem a os arquivos docker para subir o Banco de Dados<br>
│ ├── northwind.sql # SQL utilizado para criar o Banco e as tabelas utilizadas no projeto<br> 
│ ├── Dockerfile # arquivo docker para inicializar o postgre<br>
│ └── [Readme.md](InfraBD/Readme.md) # Instruções para inicializar o banco no docker
├── app/ # Pasta com o projeto python<br>
│ ├── Util/ # Utilitários e modulos Python<br>
│ │ ├── bd.py # Arquivo python com função para conectar no Banco de Dados<br>
│ │ └── paramsBD.yml # Arquico com as configurações para conexão com o Banco de Dados<br>
│ ├── crudCateg.py # MicroServiso de CRUD de Categorias<br>
│ └── [Readme.md](app/Readme.md) # Instruções para inicializar o APP
├── docker-compose.yml # define a configuração para dois serviços: app e db.
├── Dockerfile # define a configuração para construir uma imagem Docker para uma aplicação Flask.
└── Readme.md # Arquivo com instruções gerais

## Configuração

### Requisitos

- Python 3.x
- PostgreSQL

### Instalação

1. Clone o repositório:
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd AulaMicroservico-main
    ```

2. Crie um ambiente virtual e ative-o:
    ```bash
    python -m venv venv
    source venv/bin/activate  # No Windows use `venv\Scripts\activate`
    ```

3. Instale as dependências:
    ```bash
    pip install -r requirements.txt
    ```

4. Configure as variáveis de ambiente no arquivo `.env`:
    ```properties
    # Configurações do PostgreSQL
    POSTGRES_USER=postgres
    POSTGRES_PASSWORD=postgres
    POSTGRES_DB=app_database
    POSTGRES_PORT=5432
    # Configurações da aplicação Python
    FLASK_ENV=development
    FLASK_DEBUG=1
    APP_PORT=8000
    # Outras configurações
    LOG_LEVEL=INFO
    ```

## Execução

1. Inicie o servidor PostgreSQL.

2. Execute a aplicação Flask:
    ```bash
    flask run --port=$APP_PORT
    ```

3. Acesse a aplicação em `http://localhost:8000`.

## Como Rodar o Docker-Compose

Para rodar o projeto utilizando o Docker-Compose, siga os passos abaixo:

1. Certifique-se de que você tem o Docker e o Docker-Compose instalados na sua máquina.

2. No diretório raiz do projeto, remova a versão obsoleta do `docker-compose.yml`:

    ```powershell
    (Get-Content docker-compose.yml) -notmatch 'version:' | Set-Content docker-compose.yml
    ```

3. Execute o seguinte comando para parar e remover quaisquer contêineres existentes:

    ```sh
    docker-compose down
    ```

4. Remova o volume de dados do PostgreSQL (se necessário):

    ```sh
    docker volume rm AulaMicroservico_postgres_data
    ```

5. Execute o comando para iniciar os contêineres com o Docker-Compose:

    ```sh
    docker-compose up --build
    ```

6. O serviço Flask estará disponível em `http://localhost:5000` e o banco de dados PostgreSQL estará disponível na porta `5432`.

Esses passos irão construir e iniciar os contêineres definidos no `docker-compose.yml`, garantindo que o ambiente esteja configurado corretamente.

## Contribuição

1. Faça um fork do projeto.
2. Crie uma nova branch (`git checkout -b feature/nova-feature`).
3. Faça commit das suas alterações (`git commit -am 'Adiciona nova feature'`).
4. Faça push para a branch (`git push origin feature/nova-feature`).
5. Crie um novo Pull Request.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.